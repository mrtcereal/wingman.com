
<img class="scale" src="<?php print image_style_url('215x149', $row->_field_data['nid']['entity']->field_image['und'][0]['uri']);?>" alt="Image"/>
<a href="<?php print file_create_url($row->_field_data['nid']['entity']->field_image['und'][0]['uri']);?>" rel="prettyPhoto" 
title="<?php print $fields['title_1']->content; ?>" class="view">View</a>         
<?php print $fields['view_node']->content; ?>
<?php print $fields['title']->content; ?>
                      


                    