<!-- BEGIN: slider -->
<div id="ei-slider" class="ei-slider">
<ul class="ei-slider-large">
<?php foreach ($rows as $id => $row): ?>
<?php print $row; ?>
<?php endforeach; ?>
</ul>
<div>