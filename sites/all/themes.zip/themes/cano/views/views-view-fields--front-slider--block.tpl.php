 <li>
<?php print $fields['field_image']->content; ?>
<div class="ei-title">
<h2><?php print $fields['title']->content; ?></h2><br />
<h3><?php print $fields['body']->content; ?></h3>
</div>
</li>
