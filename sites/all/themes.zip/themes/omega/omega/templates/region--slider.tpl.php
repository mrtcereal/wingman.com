<div>

    <?php print $content; ?>

</div>